package com.school.student_service.aspect;

public class LoggingAspect {

}
